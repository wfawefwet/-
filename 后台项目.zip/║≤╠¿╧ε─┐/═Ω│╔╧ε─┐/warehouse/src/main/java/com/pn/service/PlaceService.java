package com.pn.service;

import com.pn.entity.Place;

import java.util.List;

public interface PlaceService {

    //查询所有产地的业务方法
    public List<Place> queryAllPlace();
}
