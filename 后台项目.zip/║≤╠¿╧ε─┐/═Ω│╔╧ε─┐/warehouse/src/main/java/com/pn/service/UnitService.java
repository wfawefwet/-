package com.pn.service;

import com.pn.entity.Unit;

import java.util.List;

public interface UnitService {

    //查询所有单位的业务方法
    public List<Unit> queryAllUnit();
}
