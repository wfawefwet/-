package com.pn.service;

import com.pn.entity.Brand;

import java.util.List;

public interface BrandService {

    //查询所有品牌的业务方法
    public List<Brand> queryAllBrand();
}
