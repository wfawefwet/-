package com.pn.service;

import com.pn.entity.Auth;
import java.util.List;

public interface AuthService {

	//根据用户id查询用户权限(菜单)树的业务方法
	public List<Auth> findAuthTree(int userId);

}
