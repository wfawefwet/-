package com.pn.service;

import com.pn.entity.User;

public interface UserService {

	//根据用户名查找用户的业务方法
	public User findUserByCode(String userCode);
}
