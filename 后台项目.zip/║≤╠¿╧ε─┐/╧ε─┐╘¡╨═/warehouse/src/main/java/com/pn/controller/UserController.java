package com.pn.controller;

import java.util.List;
import com.pn.entity.*;
import com.pn.service.*;
import com.pn.utils.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/user")
public class UserController {

	//注入AuthService
	@Autowired
	private AuthService authService;

	//注入TokenUtils
	@Autowired
	private TokenUtils tokenUtils;

	/**
	 * 加载当前登录用户权限(菜单)树的url接口/user/auth-list
	 *
	 * @RequestHeader(WarehouseConstants.HEADER_TOKEN_NAME) String clientToken
	 * 将请求头Token的值即前端归还的token,赋值给请求处理方法的参数String clientToken
	 */
	@GetMapping("/auth-list")
	public Result authList(@RequestHeader(WarehouseConstants.HEADER_TOKEN_NAME) String clientToken) {
		//从前端归还的token中解析出当前登录用户的信息
		CurrentUser currentUser = tokenUtils.getCurrentUser(clientToken);
		//根据用户id查询用户权限(菜单)树
		List<Auth> authTreeList = authService.findAuthTree(currentUser.getUserId());
		//响应
		return Result.ok(authTreeList);
	}
}
