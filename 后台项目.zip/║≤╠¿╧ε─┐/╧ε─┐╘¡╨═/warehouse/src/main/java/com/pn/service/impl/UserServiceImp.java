package com.pn.service.impl;

import com.pn.entity.User;
import com.pn.mapper.UserMapper;
import com.pn.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class UserServiceImp implements UserService {

	//注入UserMapper
	@Autowired
	private UserMapper userMapper;

	//根据用户名查找用户的业务方法
	@Override
	public User findUserByCode(String userCode) {
		return userMapper.findUserByCode(userCode);
	}
}
