package com.pn.mapper;

import com.pn.entity.User;

public interface UserMapper {

	//根据用户名查找用户的方法
	public User findUserByCode(String userCode);

}
